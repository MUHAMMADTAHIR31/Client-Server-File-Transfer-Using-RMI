import java.io.IOException;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.Remote;


public class ClientFile { 
    public static void main(String[] args) {

        String fileName = "file.pdf";
        System.out.println("Client started");

        try {
            Remote remote = Naming.lookup("FileServer");
            FileServer server = null;
            if(remote instanceof FileServer)
                server = (FileServer) remote;

            System.out.println("SENDING FILE: " + fileName);
            SimpleRemoteInputStream istream = new SimpleRemoteInputStream(new FileInputStream(fileName));
            server.sendFile(istream.export());
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}