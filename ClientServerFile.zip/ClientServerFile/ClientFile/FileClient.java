import java.io.*;

import java.rmi.*;

public class FileClient{

	public static void main(String argv[]) {

		try {
			
			FileInterface fi = (FileInterface) Naming.lookup("ali");
			byte[] filedata =  fi.downloadFile("FileServer");
			File file = new File("FileServer");

			BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file.getName()));
			output.write(filedata,0,filedata.length);
			System.out.println("File Write");
			output.flush();
			output.close();
			
		} catch(Exception e) {
			System.err.println("FileServerption: "+ e.getMessage());
			e.printStackTrace();
		}
	} 
}