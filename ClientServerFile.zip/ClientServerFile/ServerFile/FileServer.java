import java.io.*;
import java.rmi.*;

public class FileServer {

	public static void main(String argv[]) {

		try {

			FileInterface fi = new FileImpl("FileServer");
			Naming.rebind("ali", fi);
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}   