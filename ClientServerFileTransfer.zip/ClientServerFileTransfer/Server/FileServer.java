import java.rmi.Naming;
import java.rmi.RemoteException;

import java.net.MalformedURLException;
 
public class FileServer {
 
	public static void main(String[] args)throws Exception{
		try {
			
			FileImp file = new FileImp();
			Naming.rebind("ali", file);
			
		} catch (RemoteException e) {
				e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}