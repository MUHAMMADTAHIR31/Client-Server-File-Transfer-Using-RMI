import java.rmi.Remote;
import java.rmi.RemoteException;
 
public interface FileInterface extends Remote{
 
	public void upload(String filename, byte[] file) throws RemoteException;
}	
