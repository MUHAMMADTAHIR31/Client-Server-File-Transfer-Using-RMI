import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import java.net.MalformedURLException;

public class FileImp extends UnicastRemoteObject implements FileInterface{ 
  
	public FileImp()throws Exception{
		super();
	}

	public void upload(String filename, byte[] fileContent) throws RemoteException{
		
		File file = new File(filename);
		
		try {
			
			if (!file.exists())
			file.createNewFile();
			
			BufferedOutputStream os = new BufferedOutputStream(new FileOutputStream(file));
			os.write(fileContent);
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}