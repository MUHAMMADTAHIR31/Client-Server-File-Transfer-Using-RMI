
 import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
 
public class FileClient {
	
	public static void main(String[] args) {
		try {
			
			FileInterface fileDataService = (FileInterface) Naming.lookup("ali");
			fileDataService.upload("F:/A Java Programming/RMI JAVA/ClientServerFileTransfer/Client/test", new FileClient().fileToByte("F:/A Java Programming/RMI JAVA/ClientServerFileTransfer/Server/test.txt"));
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private byte[] fileToByte(String filename){
		byte[] b = null;
		try {
			
			File file = new File(filename);
			
			b = new byte[(int) file.length()];
			BufferedInputStream is = new BufferedInputStream(new FileInputStream(file.getName()));
			is.read(b);
			
		} catch (Exception e) {

			e.printStackTrace();
		}
		return b;
	}
}